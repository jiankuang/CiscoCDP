import urllib.request, urllib.parse, json

baseUrl = 'http://10.10.20.6/apigw/devnetlabapi/cdp/v1'

# real time device data requests require two query params: UserKey and SensorCustomerKey
queryParams =  urllib.parse.urlencode({'UserKey': '500102', 'SensorCustomerKey' : '500050', 'AppKey' : 'CDP-App'})

lightUrl = baseUrl + '/devices/lighting?%s' % queryParams 

requestHeaders = {
    'WSO2-Authorization' : 'oAuth Bearer 88b657e9e7e8220b44ba1b6ddfe9c8', # app_access_token
    'Authorization' : 'Bearer zk3Hd1YpJibAVEXFIssTml93diII', # api_access_token
    'Accept': 'application/json'
}


# TQL: when we need to get all lights, we put {ne:""}. I guess ne means not equal; not equal to "", means all the lights
# get single light
postData = {
    "Query":{
        "Find":{
            "Light":{
                "sid":"Simulated__DEVNET002__lBellzone01n0001"
            }
        }
    }
}
print('postData' + '*'*50)
print(postData)
data = urllib.parse.urlencode(postData)
print('data' + '*'*50)
print(data)
binary_data = data.encode('utf-8')
print('binary_data' + '*'*50)
print(binary_data)
request = urllib.request.Request(lightUrl, binary_data, requestHeaders)
response = urllib.request.urlopen(request)
print('before change' + '*'*50)
print(response.read().decode('utf-8'))

# # change intensityLevel of single light
# postData = {
#     "Query":{
#         "Find":{
#             "Format":"version",
#             "Light":{
#                 "sid":"Simulated__DEVNET002__lBellzone01n0001"
#             }
#         },
#         "for":{
#             "each":"light",
#             "in":"Find.Result.Light",
#             "SetLocalData":{
#                 "key":"light.state.intensityLevel.value",
#                 "value":"100"
#             }
#         },
#         "Update":{
#             "from":"Result",
#             "Include":"$Response.Message.Value.Find"
#         }
#     }
# }

# data = urllib.parse.urlencode(postData)
# binary_data = data.encode('utf-8')

# request = urllib.request.Request(lightUrl, binary_data, requestHeaders)
# response = urllib.request.urlopen(request)
# print('change' + '*'*50)
# print(response.read())

# # after change, get light status
# postData = {
#     "Query":{
#         "Find":{
#             "Light":{
#                 "sid":"Simulated__DEVNET002__lBellzone01n0001"
#             }
#         }
#     }
# }

# data = urllib.parse.urlencode(postData)
# binary_data = data.encode('utf-8')

# request = urllib.request.Request(lightUrl, binary_data, requestHeaders)
# response = urllib.request.urlopen(request)
# print('after change' + '*'*50)
# print(response.read())
